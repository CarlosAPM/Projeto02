package operadores;

public class Matematicos {

  public static void main(String[] args) {

    System.out.println(0 + 1);

    System.out.println(3 - 1);

    System.out.println(3 * 1);

    System.out.println(8 / 2);

    System.out.println(8 % 2); //módulo - resto da divisão

    var numero = 10;
    numero *= 2;
    System.out.println(numero);

  }
}
